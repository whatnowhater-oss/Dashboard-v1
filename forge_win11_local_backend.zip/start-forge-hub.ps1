# start-forge-hub.ps1 — Forge Command Local Windows 11 Launcher (RTX 5070 Ti 16GB)
$ErrorActionPreference = "Stop"
Write-Host "=== Starting Forge Command Local $0/Day Stack ===" -ForegroundColor Cyan

# Cap Ollama resident models to 1 by default so 14B weights never spill into DDR5 RAM
$env:OLLAMA_MAX_LOADED_MODELS = "1"
$env:OLLAMA_KEEP_ALIVE = "5m"

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Error "Python 3 is required on PATH."
}

Write-Host "Checking FastAPI + Uvicorn + HTTPX dependencies..." -ForegroundColor Yellow
python -m pip install --quiet fastapi uvicorn httpx pydantic python-multipart

Write-Host "Launching Forge Local Backend at http://127.0.0.1:8765 ..." -ForegroundColor Green
Start-Process "http://127.0.0.1:8765"
python .\forge_local_backend.py
